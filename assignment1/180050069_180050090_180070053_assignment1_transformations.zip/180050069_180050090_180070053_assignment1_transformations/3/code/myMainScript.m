clear;
close all;
clc;
myplot('../data/man.jpeg', '../images/man.png', 1);
myplot('../data/statue.png', '../images/statue.png', 2);
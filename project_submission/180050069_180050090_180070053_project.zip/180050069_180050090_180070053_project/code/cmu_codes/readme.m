the utils function used by cmu database are slightly different from that used by other database beacuse of .pgm file format. Hence, it has been added in a spearate folder.
